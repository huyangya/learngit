package com.example.myapplication;

public class VideoConstant {

    //视频地址
    public static String[][] mVideoUrls = {{
            "https://gslb.miaopai.com/stream/P4DnrjGZ7PzC2LfQK9k2cAKEIw39GiixIBpIHA__.mp4",
            "https://gslb.miaopai.com/stream/P4DnrjGZ7PzC2LfQK9k2cAKEIw39GiixIBpIHA__.mp4",

    }
    };

    //封面图片
    public static String[][] mVideoThumbs = {{
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1526158872907&di=410c4c0fdc85f768e6b4fb8a8b6cf208&imgtype=0&src=http%3A%2F%2F09.imgmini.eastday.com%2Fmobile%2F20180506%2F20180506234300_a1330efaec84d2361efd72e3976ee181_2.jpeg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1526158872907&di=410c4c0fdc85f768e6b4fb8a8b6cf208&imgtype=0&src=http%3A%2F%2F09.imgmini.eastday.com%2Fmobile%2F20180506%2F20180506234300_a1330efaec84d2361efd72e3976ee181_2.jpeg",

    },
    };

    //标题
    public static String[][] mVideoTitles = {{
            "于文文 - 体面",
            "于文文 - 体面",

    },
    };
}
